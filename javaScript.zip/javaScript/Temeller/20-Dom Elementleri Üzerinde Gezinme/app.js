let value;

const todoList = document.querySelector(".list-group");
const todo = document.querySelector(".list-group-item:nth-child(2)");
const cardrow = document.querySelector(".card.row");

value = todoList;
value = todo;
value = cardrow;

// Child Nodes

value = todoList.childNodes;
value = todoList.childNodes[0];

// Children -Element

value = todoList.children;
value = todoList.children[0];
value = todoList.children[todoList.length - 1];
value = todoList.children[2].textContent = "Değiştir";


value = cardrow;
value = cardrow.children;
value = cardrow.children[0].children[1].textContent = "burasınıda değiştir";

value = todoList;
value = todoList.firstElementChild;
value = todoList.lastElementChild;
value = todoList.children.length; // uzunluk 4
value = todoList.childElementCount; //uzunluk 4

// Ebeveyin
value = cardrow;
value = cardrow.parentElement;
value = cardrow.parentElement.parentElement;

// kardeşler -ortak olan elementler
value = todo;
value = todo.previousElementSibling;//bir önceki
value = todo.nextElementSibling;//bir sonraki
value = todo.nextElementSibling.nextElementSibling;//2 sonraki
value = todo.previousElementSibling.previousElementSibling;//2 önceki
















console.log(value);