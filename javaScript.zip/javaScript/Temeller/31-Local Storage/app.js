// Local Storage

// SetItem

// localStorage.setItem("hareket","burpee");
// localStorage.setItem("tekrar",50); // 50 String olarak kaydeddiyor

// Get Item

// const value = localStorage.getItem("tekrar");
// console.log(value); //50
// console.log(typeof value); //String

// Clear Local Storage
// localStorage.clear();


// if(localStorage.getItem("hareket") === null){
//     console.log("sorgulandıgınız veri bulunmuyor");
// }
// else{
//     console.log("sorguladıgınız veri bulunuyor");
// }

// Local Storage -Array Yazma

// const todos = ["Todo 1","Todo 2","Todo 3"];
// // localStorage.setItem("todos",JSON.stringify(todos));//Array gibi yazmak için JSON.stringify();

// const value1 = JSON.parse(localStorage.getItem("todos"));//JSON.parse(); string array çevirir
// console.log(value1);

// // Clear Local Storage
// localStorage.clear();

const form = document.getElementById("todo-form");
const todoInput = document.getElementById("todo");

form.addEventListener("submit",addTodo);

function addTodo(e){
    const value = todoInput.value;

    let todos;

    if(localStorage.getItem("todos") === null) {
        todos = [];
    }
    else{
        todos = JSON.parse(localStorage.getItem("todos"));
    }

    todos.push(value);

    localStorage.setItem("todos",JSON.stringify(todos));

}
localStorage.clear();