// Var

var name = "Metehan Turgut";
console.log(name);

// Let

let a,b;

a = 10;
b = 20;
console.log(a/b);

let name1 = "Metehan";

console.log(name1);
name1 = "trgt";
console.log(name1);

// Const

const name2 ="Metehan__00";
console.log(name2);

// Const Javascript Mülakat Sorusu

const dizi = [1,2,3,4,5];
console.log(dizi);
// .push(); references ekleme yapınca hata vermez.
dizi.push(6);
console.log(dizi);
