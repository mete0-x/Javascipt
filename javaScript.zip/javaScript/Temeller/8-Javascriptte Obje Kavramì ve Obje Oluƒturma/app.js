 let value;

 const programmer = {
     name : "Metehan TURGUT",
     age : 23,
     email:["python","java","javascript"],

     address : {
        city : "İstanbul",
        street : "şile"
     },

     work : function(){
          console.log("Program Çalışıyor...");
     }

 }

 value = programmer.langs;

 value = programmer.email; // Genel olarak
 value = programmer["email"];

 value = programmer.address.city;

 programmer.work();

 const programmers = [
    {name:"mustafa murat",age:25} ,
    {name:"oğuz",age : 25} 
 ];





 console.log(value);