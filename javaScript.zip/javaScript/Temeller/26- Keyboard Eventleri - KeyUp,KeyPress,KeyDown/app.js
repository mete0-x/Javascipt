// Klavye Eventleri

// keypress
document.addEventListener("keypress",run); //keypress, klavye 

function run(e){
    console.log("hello");
    console.log(e.which); //basılan tuşun asci tablosundaki değerini verir
    
}

// keydown
document.addEventListener("keydown",run); 

function run(e){
  
    console.log(e.which); //basılan tuşun asci tablosundaki değerini verir
    console.log(e.key); // bassılan tuşu gösterir
}

// keyup
document.addEventListener("keyup",run); //tuşa basılıp bırakıldıktan sonra basılan değer görünür

function run(e){
  
    console.log(e.which); //basılan tuşun asci tablosundaki değerini verir
    console.log(e.key); // bassılan tuşu gösterir
} 

// keyup öreneği
const header = document.querySelector(".card-header");
const todoInput = document.querySelector("#todo");

todoInput.addEventListener("keyup", changeText);

function changeText(e){
    header.textContent = e.target.value;
    // console.log(e.target.value);
}








