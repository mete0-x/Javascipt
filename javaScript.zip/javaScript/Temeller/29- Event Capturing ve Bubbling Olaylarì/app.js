// Event Bubbling
document.querySelector(".cantainer").addEventListener("click",function(){
    console.log("Div Container");
});

// Event Capturing veya Delegation
const cardbody = document.querySelectorAll(".card-body")[1];

cardbody.addEventListener("click",run);

function run(e) {
    console.log("hello");
}
