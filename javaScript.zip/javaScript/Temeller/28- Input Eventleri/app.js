const filter = document.getElementById("filter");
 
// DOMContentLoaded 
document.addEventListener("DOMContentLoaded",load);

function load(e){
    console.log("sayfa yüklendi");
}

// Focus
filter.addEventListener("focus",run);

function run(e) {
    console.log(e.type);
}

// Blur
filter.addEventListener("blur",run);

// Paste
filter.addEventListener("paste",run);

// Copy
filter.addEventListener("copy",run);

// Cut
filter.addEventListener("cut",run);

// Select
filter.addEventListener("select",run);

function run(e) {
    console.log(e.type);
}