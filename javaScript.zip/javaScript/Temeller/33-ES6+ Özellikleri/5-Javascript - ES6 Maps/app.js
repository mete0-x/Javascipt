// Mapler - Key(Anahtar) - Value(Değer)

// let myMap = new Map(); //Oluşturma

// console.log( myMap);

// const key1 = " Metehan";
// const key2 = {a:10,b:20,c:30};
// const key3 = () => 2 ;

// Set 
// myMap.set(key1,"String değer");
// myMap.set(key2,"Object Literal Değer");
// myMap.set(key3,"Function Deger");

// Get
// console.log(myMap.get(key1));
// console.log(myMap.get(key2));
// console.log(myMap.get(key3));

// console.log( myMap);

// Map Boyutu
// console.log(myMap.size);

// const citles = new Map();

// citles.set("Ankara",5);
// citles.set("İstanbul",15);
// citles.set("İzmir",4);

// // For Each

// citles.forEach(function(value,key){
//     console.log(key,value);
// })

// // For Of

// for(let [key,value] of citles){ // Destructing
//     console.log(key,value);
// }

// // Map Keys

// for(let key of citles.keys()) {
//     console.log(key);
// }
// // Map Values

// for(let value of citles.values()) {
//     console.log(value);
// }

// // Arraylerden Map Oluşturma
// const array = [["key1","value1"],["key2","value2"]];

// const lastMap = new Map(array);

// console.log(lastMap);

// Maplerden Array Oluşturma

const citles1 = new Map();

citles1.set("Ankara",5);
citles1.set("İstanbul",15);
citles1.set("İzmir",4);

const array = Array.from(cities1);
// [["Ankara",5],["İstanbul",15],["İzmir",4]]
console.log(array);









