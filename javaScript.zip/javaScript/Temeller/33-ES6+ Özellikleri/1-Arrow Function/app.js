const merhaba = function() {
    console.log("hello");
}
merhaba();

//Arrow Function
const merhaba1 = () => {
    console.log("Word");
}
merhaba1();

const merhaba2 = (firstname,lastname) => console.log("merhaba",firstname,lastname);merhaba2("Metehan","TURGUT");

const cube = function(x) {
    return x*x*x;
}
console.log(cube(4));

const cube1 = x => x*x*x; 
console.log(cube1(6));
