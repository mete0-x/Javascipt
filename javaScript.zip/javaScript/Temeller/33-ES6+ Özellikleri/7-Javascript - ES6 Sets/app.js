// Setler - Kümeler

const myset = new Set();

myset.add(100);
myset.add(100);
myset.add(3.75);
myset.add("Metehan");
myset.add(false);
myset.add([4,8,12]);
myset.add({a:7,b:9,d:98});

const myset2 = new Set([154,89.78,"Ronaldo"]);

console.log(myset);
console.log(myset2);

// Size
console.log(myset.size);
console.log(myset2.size);

// Delete Metodu

myset.delete("Metehan");
console.log(myset);

// Has Metodu

console.log(myset.has("Metehan"));
console.log(myset.has(100));
console.log(myset.has(555));

// For Each

myset.forEach(function(value){
    console.log(value);
})

// For of

for(let value of myset){
    console.log(value);
}

// Array oluşturma

const array = Array.from(myset);
console.log(a);