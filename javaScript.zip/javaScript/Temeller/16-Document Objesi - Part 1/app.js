// windo Object
let value;

value = document;
value = document.all; //HTMLAllCollection
value = document.all.length;
value = document.all[0];
value = document.all[document.all.length-1];

const elements = document.all;
// for(let i =0;i < elements.length;i++){
//     console.log(elements[i]);
// }

// elements.forEach(function(element){ // HTMLAllCollection forEach kullanılmıyor
//      console.log(element);
// });

const collections = Array.from(document.all);// HTMLAllCollection forEach kullanmack için array dönüştür.

collections.forEach(function(collection){
     console.log(collection);
});


value = document.body;
value = document.head;

value = document.location;
value = document.location.hostname;
value = document.location.port;

value = document.URL;

value = document.characterSet;

console.log(value);