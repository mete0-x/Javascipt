let value;

value = document;

// Scripler

value = document.scripts;

value = document.scripts.length;

//  Linkler

value = document.links;
value = document.links[0];
value = document.links[document.links.length-1];
value = document.links[document.links.length-1].getAttribute("class");
value = document.links[document.links.length-1].getAttribute("href");
value = document.links[document.links.length-1].className;
value = document.links[document.links.length-1].classList;

// formlar

value = document.forms;
value = document.forms.lengts;
value = document.forms[0];
value = document.forms["form"];
value = document.forms[0].id;
value = document.forms[0].getAttribute("id");





console.log(value);