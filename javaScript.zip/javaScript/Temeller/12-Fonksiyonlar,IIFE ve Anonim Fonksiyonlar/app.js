// Fonksiyon tanımlama 

function merhaba(name,age){
    console.log('isim'+name+'yas'+age);
}
// merhaba("metehan",25);  //Fonksiyon Çağrısı (Function Call)
// merhaba();

function squar(a){
    return a*a;
    // console.log("Naber"); return olduğu için bu kod satırı çalişmaz
}
function cube (a){
    return a*a*a;
}

let a = squar(12);

// console.log(a);

a = cube(a); 

// console.log(a);


// Function Expression

const merhaba1 = function(name){
    console.log( "merhaba " + name);
};

// merhaba1("metehan");

// Immedately Invoked Function Expression (IIFE)

// (function(name){
//     console.log("Merhaba :" +name);
// })("metehan");

const database = {
    host:"localhost",
    add:function(){
        console.log("eklendi");
    },
    get:function(){
        console.log("elde edildi");
    },
    update:function(id){
        console.log('Id :' +id+ ' Güncellendi');
    },
    delete:function(id){
        console.log('Id: ' +id+ ' silindi');
    }
}
console.log(database.host);
database.delete(10);
database.update(8);