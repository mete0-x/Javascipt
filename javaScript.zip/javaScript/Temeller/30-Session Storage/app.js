// Session Storage - Key and Value

// Butonları Seçmek

const add = document.querySelector("#add");
const del = document.querySelector("#delete");
const clear = document.querySelector("#clear");

// Inputlar

const addkey = document.getElementById("addkey");
const addvalue = document.getElementById("addvalue");
const deletekey = documnet.getElementById("deletekey");

add.addEventListener("click",addItem);
del.addEventListener("click",deleteItem);
clear.addEventListener("cilik",clearItems);

function addItem(e){
     sessionStorage.setItem(addkey.value, addvalue.value);
}
      
function deleteItem(e){
     sessionStorage.removeItem(deletekey.value);
}

function clearItems(e){
     sessionStorage.clearItems();
}
