// Değişken Oluşturma

var a = 20;
var b = 10;
var c = 40;

console.log(a,b,c);


// Primitive (ilker veri tipi)

var a = 10; //number veri tipi
var b = 2.14; //number veri tipi

console.log(typeof a);
console.log(typeof b);

// String

var name = "Metehan";
console.log(name);
console.log(typeof name);


// Boolean

var a = true;
console.log(typeof a);

var a = null;
console.log(a);
console.log(typeof a);  // değeri !object! = javascript hata 


// undefined(tanımsız)
var x;
console.log(x);

// Reference Veri Tipleri *tüm referance veri tiplerinin typeo = object

 var numbers =([1,2,3,4,5]);
 console.log(numbers);
 console.log(typeof numbers);
 console.log(numbers[3]);

 var person = {
    name: "Metehan TURGUT ",
    age: 25
 }
 console.log(person);
 console.log(typeof person);


 var date = new Date();
 console.log(date);
 console.log(typeof date);

 var merhaba = new function(){
    console.log("merhaba");
 }
 console.log(typeof merhaba);

// Primitive ve Reference veri tipleri arasındaki fark ;

// Primitive 
var a = 10;
var b = a;
console.log(a,b);// out : 10 10 
a = 20;
console.log(a,b);// out : 20 10 

// Reference 

var a = [1,2,3];
var b = a;

a.push(4);// a dizizsine 4 değerini ekle
console.log(a,b);// out a: 1,2,3,4 & b:1,2,3,4 








