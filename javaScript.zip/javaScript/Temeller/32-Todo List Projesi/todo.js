// Tüm Elementleri Seçme
const form = document.querySelector("#todo-form");
const todoInput = document.querySelector("#todo");
const todoList = document.querySelector(".list-group");
const firstCardBody = document.querySelectorAll(".card-body")[0];
const secondCardBody = document.querySelectorAll(".card-body")[1];
const filter = document.querySelector("#filter");
const clearButton = document.querySelector("#clear-todos");

eventListeners();

function eventListeners() { // Tüm event listenerlar
    form.addEventListener("submit",addTodo);
    document.addEventListener("DOMContentLoaded",loadAllTodosToUI);
    secondCardBody.addEventListener("click",deleteTodo);
    filter.addEventListener("keyup",filterTodos);
    clearButton.addEventListener("click",clearAllTodos);
}
function clearAllTodos(e){
    if(confirm("Tümünü silmek istediğinize emin misiniz ?")){
            // Arayüzden todoları temizleme
            // todoList.innerHTML = "";
            while(todoList.firstElementChild != null) {
                todoList.removeChild(todoList.firstElementChild);
            }
            localStorage.removeItem("todos");
    }


}
function filterTodos(e){
   const filterValue = e.target.value.toLowerCase();
   const listItems = document.querySelector(".list-group-item");

   listItems.forEach(function(listItem){
      const text = listItem.textContent.toLowerCase();
       if(text.indexOf(filterValue) === -1){
        //Bulunamadı
        console.log("if durum hata ");
        listItem.setAttribute("style","display : none !importanat");
       }
       else{
        listItem.setAttribute("style","display : block");
        console.log("else durumu hata");
       }

   });
}
function deleteTodo(e){

    if (e.target.className === "fa fa-remove") {
        e.target.parentElement.parentElement.remove();
        deleteTodoFromStorage(e.target.parentElement.parentElement.textContent);
        showAlert("success","Todo başarıyla silindi...");
    }
}
function deleteTodoFromStorage(deletetodo){ // hata var çözemedim 
   let todos = getTodosFromStorge();
   
   todos.forEach(function(todo,index){
       if(todos != deletetodo){ // else durumunda hata 
        todos.splice(index,1);
        console.log("if durumu");
       }
       else{
        console.log("else durumu");
       }
   });

   localStorage.setItem("todos",JSON.stringify(todos));

}
function loadAllTodosToUI() {
    let todos = getTodosFromStorge();

    todos.forEach(function(todo){
       addTodoToUI(todo);
    })
}
function addTodo(e) {
     const newTodo = todoInput.value.trim(); // trim fonk. baştaki ve sondaki boşlukları alır
     
     if(newTodo === "") {
        /* Bootstrap 4 alert mesaj 
        <div class="alert alert-danger" role="alert">
            This is a danger alert with <a href="#" class="alert-link">an example link</a>. Give it a click if you like.
          </div>
        */
        showAlert("danger","Lütfen bir todo giriniz...");
     }
     else {
        addTodoToUI(newTodo);

        addTodoStorage(newTodo);

        showAlert("success","Todo başarıyla eklendi...");
     }



    e.preventDefault();
}
function getTodosFromStorge(){ // Storgaden Todoları Alma
    let todos;

    if(localStorage.getItem("todos") === null) {
       todos = [];
    }
    else{
     todos = JSON.parse(localStorage.getItem("todos"));
    }
    return todos;
}
function addTodoStorage(newTodo){
   let todos = getTodosFromStorge();

   todos.push(newTodo);

   localStorage.setItem("todos",JSON.stringify(todos));

}
function showAlert(type,message){
    const alert = document.createElement("div");

    // alert.className = 'alert alert-${type}';
       alert.className = `alert alert-${type}`;

       alert.textContent = message;

       firstCardBody.appendChild(alert);

    //    setTimeOut
    setTimeout(function(){
        alert.remove();
    },2000);
}
function addTodoToUI(newTodo) { 
    //String değerini list item olarak UI'ekleyecek
    /* <li class="list-group-item d-flex justify-content-between">
    Todo 1
    <a href = "#" class ="delete-item">
        <i class = "fa fa-remove"></i>
    </a>

    </li> */
    // List Item Oluşturma
    const listItem = document.createElement("li");
    // Link Oluşturma
    const link = document.createElement("a");
    link.href = "#";
    link.className = "delete-item";
    link.innerHTML = " <i class = 'fa fa-remove'></i>";
    listItem.className = "list-group-item d-flex justify-content-between";

    // Text Node Ekleme
    listItem.appendChild(document.createTextNode(newTodo));
    listItem.appendChild(link);

    // Todo List'e List Item'ı Ekleme
    todoList.appendChild(listItem);

    todoInput.value = ""; //input içindeki submit edildekten sonra sil


}