// let value;

// const firstname = "Metehan";
// const lastname = "TURGUT";
// conts langs = "Java,Python,C++";

// value = firstname +" "+lastname;
// value += "Danger"; value = value + "Danger";

// value = firstname.length; string içindeki karakter sayısı out:7
// value = firstname.concat(" ",lastname," ","00"); out:Metehan TURGUT 00

// value = firstname.toLowerCase(); küçük harf ile yaz
// value = firstname.toUpperCase(); büyük harf ile yaz

// value = firstname[0]; out:M
// value = firstname[2]; out:t
// value = firstname[6]; out:n
// value = firstname[firstname.length - 1]; out:n

// Index Of

// value = firstname.indexOf("M"); out:0
// value = firstname.indexOf("e"); out:1
// value = firstname.indexOf("h"); out:4

// Chart At 

//  value = firstname.chartAt(0); out:M
//  value = firstname.chartAt(2); out:t
//  value = firstname.chartAt(5); out:a

// Split

// value = langs.split(","); out: ["Java","Python","C++"]

// Replace

// value = langs.replaceİ("Python","CSS"); out:Java,CSS,C++

// Includes

// value = langs.includes("Java"); out:true
// value = langs.includes("asdsasa"); out:false




console.log(value);
