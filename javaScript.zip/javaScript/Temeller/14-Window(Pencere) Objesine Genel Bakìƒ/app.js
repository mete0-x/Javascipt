// console.log(window);
// console.log(this);

// Alert
alert("Merhaba");

// Confirm
const cevap = confirm("Emin misiniz?");
console.log(cevap);

// // ve

if(confirm("Emin misiniz?")){
    console.log("Sil");
}
else {
    console.log("silme");
}

// Prompt

const cevap1 = prompt("2 + 2 = ?");

if (cevap1 =="4") {
    console.log("Doğru");
}
else {
    console.log("yanlış");
}

let value;

value = window;
value = window.location;
value = window.location.host;
value = window.location.hostname;
value = window.location.port;
value = window.location.href;
// reload fonk. yenileme

if(confirm("Sayfa yenilensin mi?") ) {
    window.location.reload();
}
else {
    console.log("sayfayı yenilenmedi")
}

value = window.outerHeight;
value = window.outerWidth;

value = window.innerHeight;
value = window.innerWidth;
value = window.outerWidth;

value = window.scrollX; // scroll konumundaki değerini söyler

console.log(value);