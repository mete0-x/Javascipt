let value;

// const value1 = 10;
// const value2 = 4;

// Aritmetik Operatörler :

// value = value1 + value2; 
// value = value1 - value2;
// value = value1 * value2;
// value = value1 / value2;
// value = value1 % value2;

// math. fonc.
// value = Math.PI;
// value = Math.E;

// value = Math.round(3.5); out:4
// value = Math.round(3.4); out:3

// value = Math.cel(3.2); out:4
// value = Math.cel(3.7); out:4

// value = Math.floor(3.2); out:3
// value = Math.floor(3.7); out:3

// value = Math.sqrt(16); out:4

// value = Math.abs(-10); out: 10(mutlak değer)

// value = Math.pow(4,2); out:16

// value = Math.max(10,-2,100,35); out:100
// value = Math.min(10,-2,100,35); out:-2

// value = Math.random(); 0 dahil 1 dahil değil
value = Math.floor(Math.random()*20 + 1);









console.log(value);