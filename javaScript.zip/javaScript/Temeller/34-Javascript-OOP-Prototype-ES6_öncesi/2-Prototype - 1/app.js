// const object = new Object();
// const object2 = new Object(); 
// object.name = "Metehan";
// console.log(object);
// console.log(object2);

function Employee(name,age) {
    this.name = name;
    this.age = age;
    this.showInfos = function(){
        console.log("Bilgileri Göster...");
    }
    this.toString = function(){
        console.log("Bir employee Objesidir...");
    }
}

const emp1 = new Employee("Metehan",23);
console.log(emp1);
console.log(emp1.toString);
