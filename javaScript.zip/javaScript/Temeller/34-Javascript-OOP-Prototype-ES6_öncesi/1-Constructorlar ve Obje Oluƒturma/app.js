console.log(this); // Global Scape
 
function Empoloyee(name,age,salary) { // Yapıcı Fonksiyon - Constructor
    this.name = name;
    this.age = age;
    this.salary = salary;

    this.showInfos = function() {
        console.log(this.name,this.age,this.salary);
    }
}

const emp1 = new Empoloyee("Metehan",23,100000000000);
const emp2 = new Empoloyee("Turgut",25,999999999);
console.log(emp1,emp2);

emp1.showInfos(); emp2.showInfos();
