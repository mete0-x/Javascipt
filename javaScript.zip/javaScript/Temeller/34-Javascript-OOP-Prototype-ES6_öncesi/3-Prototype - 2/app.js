function Employeee(name,age){
    this.name = name;
    this.age = age;

    // this.showInfos = function() {
    //     console.log("İsim: "+ this.name + " Yaş: "+ this.age );
    // } !!Bellekte gereksiz yer işgal ettiği için Prototype içine fonksiyonun eklenmesi...
}
Employeee.prototype.showInfos = function() {console.log("İsim: " + this.name + " Yaş: " + this.age)}
const emp1 = new Employeee("Metehan",23);
const emp2 = new Employeee("Turgut" ,24);
emp1.showInfos();
emp2.showInfos();
console.log(emp1);
console.log(emp2);
