 const process = 1;
 
 switch(process){
    case 1:
          console.log("İşlem 1");
          break;

    case 2:
         console.log("İşlem 2");
         break;
 
     case 3:
         console.log("İşlem 3");
        break;

     default:
        console.log("Geçersiz İşlem"); 
       break;
        }