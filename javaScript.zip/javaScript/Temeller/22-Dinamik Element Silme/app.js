// Dinamik element silme

const todoList = document.querySelector("ul.list-group");
const todos = document.querySelectorAll("li.list-group-item");

// Remove Metodu

todos[0].remove(); //sil

// Remove Child

todoList.removeChild(todoList.lastElementChild);//Son child sil
todoList.removeChild(todos[3]);//Son child sil

console.log(todoList);
console.log(todos);