let value;

const numbers = [35,44,89,21,5,87,85,4]; 
//const numbers2 = new Array(1,2,3,4,5,6,7);

const langs = ["Python","Java","C++","JavaScript"];

const a = ["Merhaba",22,null,undefined,3.14];

// Uzunluk
// value = numbers.length; out:8
// Indeksleme
// value = numbers[0]; out :35
// value = numbers[2]; out:89
// value = numbers[numbers.length - 1]; out :4

// Herhangi bir indeksteki değeri değiştirme

numbers[2] = 1000;
value = numbers;

//  Index Of

value = numbers.indexOf(1000);

// Arrayin Sonuna Değer Ekleme -Push

numbers.push(2000);

// Arrayin Başına Değer Ekleme -unshift

numbers.unshift(3000);

value = numbers;

// Sonunda Değer Atma 

numbers.pop();
value = numbers;

// Başından Değer Atma 

numbers.shift();
value = numbers;


// Belli bir kısmı atma index

numbers.splice(0,3);
value = numbers;

// Arrayi Ters Çevirme Fonk. -Reverse

numbers.reverse();
value = numbers;

// Sayının ilk basamağına göre küçükten büyüğe sıralayan fonks. -sort()

numbers.sort();
value = numbers;

// küçükten büyüğe sıralama fonk.
value = numbers.sort(function(x,y){
    return x -y ;
});

// Büyükten küçüğe sıralama fonk.
value = numbers.sort(function(x,y){
    return y-x ;
});





console.log(value);





















