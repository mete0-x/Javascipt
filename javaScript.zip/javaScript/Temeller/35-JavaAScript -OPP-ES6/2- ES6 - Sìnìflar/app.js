// function Employee(age,name,salary){

//  this.name = name;
//  this.age = age;
//  this.salary = salary;
 
//  const showInfos = function(){
//     console.log("İsim :" + name + "Yaş :" + age + "Maaş :" + salary);
//  }
// }

// const emp = new Employee("Metehan",23,100000);
// console.log(emp);

class Employee {

    constructor (name,age,salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    showInfos() {
        console.log("İsim :" + name + "Yaş :" + age + "Maaş :" + salary);
    }

}

const emp = new Employee("Mete",23,90000);
// console.log(emp);
emp.showInfos();