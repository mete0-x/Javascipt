const element = document.querySelector("#clear-todos");

// Element Özellikleri
consolelog(element.id);
consolelog(element.className);
consolelog(element.classList);
consolelog(element.classList[1]);
consolelog(element.textContent);
consolelog(element.innerHTML);
consolelog(element.href);
consolelog(element.style); 

// Style ve Element Özelliklerini Değiştirme

element.className = "btn btn-primary";
element.style.color = "#000";
element.style.marginLeft = "50px";
element.href = "https//www.google.com.tr";
element.target = "_blank";
element.textContent= "silin";
element.innerHTML = "<span style ='color:green' >Silin </span>"

const elements = document.querySelectorAll(".list-group-item");
elements.forEach(function(el){
   el.style.color = "red";
   el.style.background = "#eee";
   
});

// https://www.w3schools.com/cssref/css_selectors.php

let element2 = document.querySelector("li:first-child");
element2 = document.querySelector("li:nth-child(2)");
element2 = document.querySelector("li:nth-child(3)");
element2 = document.querySelector("li:nth-child(4)");
element2 = document.querySelector("li:last-child");
element2 = document.querySelectorAll("li:nth-child(odd)");
element2 = document.querySelectorAll("li:nth-child(even)");