let value;

// Veri tiplerini String'e Çevirme

// value =  String(123);
// value =  String(3.14);
// value =  String(true);
// value =  String(false);
// value =  String(function() {console.log()});
// value =  String([1,2,3,4]);

// value = (10).toString();
// value = (3.14).toString();

// Veri tiplerini sayılara çevirme

// value = number("123");
// value = number(null);
// value = number(undefined); cevrilmiyor NaN
// value = number(function() {console.log()}); NaN
// value = number("Hello World");
// value = number([1,2,3,4]);NaN
// value = number("3.14");
// fonc. use çevirme
// value = parseFloat("3.14"); 
// value = parseInt("3");
// otomatik çevirme
// const a  = "HELLO"  + 44;
// console.log(a); out:HELLO44
// console.log(typeof a);String


console.log(value);
console.log(typeof value);