//  Karşılaştırma Operatörleri

// ==
// ===
// !=
// !==
// >
// <
// >=
// <=

console.log(2 == 2); // out:true
console.log("js" == "java"); // out:false
console.log(2 == "2"); //out: true
console.log(2 === "2"); // out: false

// Mantıksal Bağlaçlar

// Not Operatörü

console.log(!(2 != 2)); // out : true

// And Operatörü

console.log( (2 == 2) && ("Ahmet" == "Ahmet")); // out:true

// Or Operatörü

console.log( (2 == 1) || ("Ahmet" == "Ahmet")); // out:true

// if ,else, else if

const user = "mete";

if(user === "mete"){
    console.log("Kullanıcı Bulundu");
}
else{
    console.log("Kullanıcı Bulunamadı");
}
// ----------------------------------------------

const process = "1";

if(process === "1"){
    console.log("İşlem 1");
}
else if(process === "2"){
    console.log("İşlem 2");
}
else if(process === "3"){
    console.log("İşlem 3");
}
else if(process === "4"){
    console.log("İşlem 4");
}
else {
    console.log("Geçersiz işlem..");
}

// ----------------------------------------------------
const number = 100;

if(number === 100){
    console.log("Sayı 100 eşit");
}
else {
    console.log("sayı 100 eşit değil");
}
// yukardaki if bloğunun kısa yolu ;
// Ternary Operator

console.log(number === 100 ? "Sayi 100" : "Sayı 100 değil");

// {} tek satır işlem de kullanılmadanda çalışır

if(number === 100)  console.log("sayi 100");
else console.log("sayi 100 değil");















