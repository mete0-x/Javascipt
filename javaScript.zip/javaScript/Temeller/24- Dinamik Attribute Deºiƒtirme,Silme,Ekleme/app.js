const todoInput = document.getElementById("todo");
let element;

element = todoInput;
element = todoInput.classList;

todoInput.classList.add("newClass");//ekle fonk.
todoInput.classList.add("newClass2");
todoInput.classList.remove("form-control");

element = todoInput;
element = todoInput.placeholder;
element = todoInput.getAttribute("placeholder");
todoInput.setAttribute("placeholder","bu yazıyı ekle");
todoInput.setAttribute("xxxxxxx","bu yazıyı ekle");

element = todoInput;
element = todoInput.hasAttribute("name");// true veya false 
element = todoInput.removeAttribute("name");//name kaldır




console.log(element);