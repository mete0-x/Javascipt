// While Döngüleri
// let i =10;

// while(i > 0){

//     console.log(i);
   
//     // i += 1; i++
//     i -= 1;  //i--
// }

// Break and Continue

// let i = 0;

// while(i < 10){

//     console.log(i);
//     if(i == 5) {
//         break; // out:1,2,3,4,5
//     }
//     i++;
// }

// let j = 0;

// while(j < 10){

//     if (j == 3 || j ==5){
//         j++;
//         continue;
//     }
//     console.log(j);
//      j++;
// }

// Do while 

// let k = 0;

// do{
// console.log(k);
// k++;

// }while(k < 10);


// const langs = ["Python1","javascript","java"];

// let index = 0;

// while (0 < langs.length){
    
//     console.log(langs[index]);
//     index++;

// }

// for(let index = 0;index < langs.length;index++){

//     console.log(langs[index]);
// }

// langs.forEach(function(lang,index){
//     console.log(lang,index);
// });

// const users = [
//     {name:"mustafa",age:25},
//     {name:"zeynep",age:24},
//     {name:"ali",age:23}
// ];

// const names = users.map(function(user){
//     return user.name;
// });
// const ages = users.map(function(user){
//     return user.age;
// });
// console.log(names);
// console.log(ages);

const user = {
    name:"Metehan",
    age:23
}

for(let key in user){
    console.log(key,user[key]);
}