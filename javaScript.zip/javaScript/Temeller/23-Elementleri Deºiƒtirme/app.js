// REPLACE

// <h5 class="card-title" id = "tasks-title">Todolar</h5>

const cardbody = document.querySelectorAll(".card-body");

const newElement = document.createElement("h3");

newElement.className = "card-titile";
newElement.id = "task-title";
newElement.textContent = "Yeni Todolar";

// Eski element

const oldElement = document.querySelector("#tasks-title");

cardbody.replaceChild(newElement,oldElement); //değiştirme fonk.

console.log(newElement);
